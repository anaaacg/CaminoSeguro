'use strict';
// Las clases DEBEN coincidir con los nombres de Teachable Machine.
const CLASSES = [
  {name:'LIBRE',icon:'🚶',phrase:'Camino aparentemente libre',color:'#54d19b'},
  {name:'OBSTACULO',icon:'🚧',phrase:'Precaución, posible obstáculo adelante',color:'#f7bd55'},
  {name:'ESCALERA_BAJA',icon:'⬇️',phrase:'Peligro, posible escalera descendente',color:'#ff7878'},
  {name:'CALLE',icon:'🚦',phrase:'Atención, posible salida a la calle',color:'#ff9973'},
  {name:'ESCALERA_SUBE',icon:'⬆️',phrase:'Precaución, posible escalera ascendente',color:'#e0a5ff'},
  {name:'DESNIVEL',icon:'⚠️',phrase:'Precaución, posible desnivel',color:'#f5d566'}
];
const $ = id=>document.getElementById(id);
let running=false,muted=false,stream=null,model=null,raf=null,busy=false;
let prev='',streak=0,lastSpoken='',lastSpokenAt=0,historyCount=0;
const threshold=()=>Number($('threshold').value)/100;
const stable=()=>Number($('stable').value);
const barElements=new Map();
function setup(){
  const bars=$('bars');for(const c of CLASSES){const div=document.createElement('div');div.className='barRow';div.innerHTML=`<div class="barTop"><span>${c.icon} ${c.name}</span><span class="percent">0%</span></div><div class="track"><div class="fill"></div></div>`;bars.appendChild(div);div.querySelector('.fill').style.background=c.color;barElements.set(c.name,div);}
  $('startBtn').onclick=start;$('stopBtn').onclick=stop;
  $('voiceBtn').onclick=()=>{muted=!muted;$('voiceBtn').textContent=muted?'🔇 Voz silenciada':'🔊 Voz activada';if(muted&&'speechSynthesis'in window)speechSynthesis.cancel();};
  $('testVoice').onclick=()=>speak('Prueba de audio. Sistema de alertas activado.',true);
  $('threshold').oninput=()=>{$('thresholdValue').textContent=$('threshold').value+'%';resetStability();};
  $('stable').oninput=()=>{$('stableValue').textContent=$('stable').value;resetStability();};
}
function resetStability(){prev='';streak=0;lastSpoken='';lastSpokenAt=0;}
function displayPredictions(probs){const sorted=[...probs].sort((a,b)=>b.probability-a.probability);const best=sorted[0];for(const c of CLASSES){const p=probs.find(x=>x.className===c.name)?.probability||0;const bar=barElements.get(c.name);bar.querySelector('.fill').style.width=(p*100).toFixed(1)+'%';bar.querySelector('.percent').textContent=Math.round(p*100)+'%';}if(!best)return;$('prediction').textContent=best.className;$('confidence').textContent=(best.probability*100).toFixed(1)+'%';$('fakeIcon').textContent=CLASSES.find(x=>x.name===best.className)?.icon||'👁️';$('fakeLabel').textContent=best.className;alertLogic(best);}
function alertLogic(best){if(best.probability<threshold()){resetCandidate();return;}if(best.className===prev){streak++;}else{prev=best.className;streak=1;}if(streak<stable())return;if(best.className==='LIBRE')return;const now=Date.now();if(best.className===lastSpoken&&now-lastSpokenAt<6000)return;if(now-lastSpokenAt<2200)return;const phrase=CLASSES.find(x=>x.name===best.className)?.phrase||'Precaución';lastSpoken=best.className;lastSpokenAt=now;logAlert(phrase);speak(phrase);}
function resetCandidate(){prev='';streak=0;}
function speak(text,force=false){if(muted&&!force)return;if(!('speechSynthesis'in window)){$('status').textContent='El navegador no soporta síntesis de voz';return;}try{speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.lang='es-ES';u.rate=1.02;u.pitch=1;const es=speechSynthesis.getVoices().find(v=>v.lang?.toLowerCase().startsWith('es'));if(es)u.voice=es;speechSynthesis.speak(u);}catch(err){console.error('Voz:',err);}}
function logAlert(text){if(!historyCount)$('history').replaceChildren();historyCount++;const li=document.createElement('li');li.textContent=`${new Date().toLocaleTimeString()} — ${text}`;$('history').prepend(li);while($('history').children.length>15)$('history').lastChild.remove();}
async function start(){if(running)return;running=true;$('startBtn').disabled=true;$('stopBtn').disabled=false;resetStability();
try{$('status').textContent='Cargando librerías de IA…';await loadLibrary('https://cdn.jsdelivr.net/npm/@tensorflow/tfjs@4.22.0/dist/tf.min.js','tf');await loadLibrary('https://cdn.jsdelivr.net/npm/@teachablemachine/image@0.8.5/dist/teachablemachine-image.min.js','tmImage');const base='./model/';$('status').textContent='Cargando modelo…';model=await tmImage.load(base+'model.json',base+'metadata.json');const expected=['LIBRE','OBSTACULO','DESNIVEL','ESCALERA_BAJA','ESCALERA_SUBE','CALLE'];const actual=model.getClassLabels().map(x=>x.trim().toUpperCase());if(JSON.stringify(actual)!==JSON.stringify(expected))throw new Error('Las seis clases del modelo no coinciden con el proyecto: '+actual.join(', '));$('status').textContent='Solicitando webcam…';stream=await navigator.mediaDevices.getUserMedia({audio:false,video:{facingMode:{ideal:'environment'},width:{ideal:640},height:{ideal:480}}});$('camera').srcObject=stream;await $('camera').play();$('camera').style.display='block';$('fakeView').style.display='none';$('status').textContent='IA activa: clasificando imágenes en vivo';loop();}
catch(err){console.error(err);$('status').textContent='Error: '+err.message+' (verifica archivos del modelo, internet y permisos de cámara).';stop(false);}}
async function loadLibrary(src,key){if(window[key])return;await new Promise((resolve,reject)=>{const s=document.createElement('script');s.src=src;s.onload=resolve;s.onerror=()=>reject(new Error('No se pudo cargar la librería desde '+src));document.head.appendChild(s);});}
async function loop(){if(!running)return;if(!busy&&$('camera').readyState>=2){busy=true;try{const p=await model.predict($('camera'));const normalized=p.map(x=>({className:x.className.trim().toUpperCase(),probability:x.probability}));displayPredictions(normalized);}catch(err){$('status').textContent='Fallo de clasificación: '+err.message;console.error(err);stop();return;}finally{busy=false;}}if(running)raf=requestAnimationFrame(loop);}
function stop(setMessage=true){running=false;if(raf)cancelAnimationFrame(raf);raf=null;if(stream){stream.getTracks().forEach(t=>t.stop());stream=null;}$('camera').pause();$('camera').srcObject=null;$('camera').style.display='none';$('fakeView').style.display='flex';$('startBtn').disabled=false;$('stopBtn').disabled=true;resetStability();if(setMessage)$('status').textContent='Detenido';if('speechSynthesis'in window)speechSynthesis.cancel();}
setup();
