# CaminoSeguro IA — Versión HTTPS con modelo real

Aplicación web de asistencia visual experimental. Utiliza únicamente el modelo original de seis clases: LIBRE, OBSTACULO, DESNIVEL, ESCALERA_BAJA, ESCALERA_SUBE y CALLE. **No hay modo demostración ni clase PERSONA.**

## Ejecutar localmente

1. Extrae el ZIP.
2. Abre una consola en la carpeta `vision_accesible_tm`.
3. Ejecuta `py -m http.server 8000`.
4. Abre `http://localhost:8000` en la computadora; toca **Iniciar cámara e IA**.

## Ejecutar desde el iPhone

Sirve toda la carpeta en tu alojamiento HTTPS (conserva los archivos en `model/`). Abre la URL HTTPS en Safari, da permisos de cámara y pulsa **Iniciar cámara e IA**. La cámara trasera se solicita por defecto. Servir desde HTTP de otra computadora en la LAN normalmente no habilita la cámara: usa HTTPS.

## Requisitos

- `model/model.json`, `model/metadata.json`, `model/weights.bin` del modelo original.
- Conexión a internet para las librerías TensorFlow.js y Teachable Machine cargadas desde jsDelivr.
- Un navegador compatible con `getUserMedia` y `speechSynthesis`. En iPhone la voz depende de Safari y permisos del dispositivo.

La inferencia se realiza en el navegador después de cargar el modelo. Umbral inicial de confianza 82 %, 3 lecturas consecutivas. Es un prototipo no validado como dispositivo de movilidad; no usarlo como única guía para desplazarse o cruzar calles.
